// copy
balapaCop("3D Hover Interaction", "rgba(255,255,255,.5)");